<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Accueil — FraisMarché Caisse</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Poppins:wght@500;600;700&family=Roboto+Mono:wght@400;500;600&display=swap" rel="stylesheet">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="/style.css" rel="stylesheet">
</head>
<body>

  <!-- Barre mobile (visible < lg) -->
  <nav class="navbar mobile-topbar d-lg-none">
    <div class="container-fluid">
      <button class="btn-toggle" type="button" data-bs-toggle="offcanvas" data-bs-target="#appSidebar" aria-controls="appSidebar" aria-label="Ouvrir le menu">
        <i class="bi bi-list"></i>
      </button>
      <span class="navbar-brand mb-0">FraisMarché</span>
      <span style="width:1.4rem;"></span>
    </div>
  </nav>

  <div class="app-layout">

    <!-- ===================== SIDEBAR (commun accueil + saisie) ===================== -->
    <div class="offcanvas-lg offcanvas-start app-sidebar d-flex flex-column" tabindex="-1" id="appSidebar">

      <div class="offcanvas-header d-lg-none">
        <span class="brand-name display-font">FraisMarché</span>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#appSidebar" aria-label="Fermer"></button>
      </div>

      <div class="offcanvas-body d-flex flex-column p-0">

        <div class="sidebar-brand d-none d-lg-flex">
          <span class="brand-icon"><i class="bi bi-bag-check-fill"></i></span>
          <span class="brand-name">FraisMarché</span>
        </div>

        <div class="sidebar-user d-flex align-items-center gap-2">
          <div class="user-avatar"><i class="bi bi-person-fill"></i></div>
          <div>
            <div class="user-name" data-user-name><?= session()->get('isLoggedIn') ? session()->get('user_nom') : '—'?></div>
            <div class="user-role" data-user-role><?= session()->get('isLoggedIn') ? session()->get('identifiant') : '—'?></div>
          </div>
        </div>

        <div class="sidebar-caisse">
          <span class="caisse-label">Caisse active</span>
          <span class="caisse-badge is-empty" data-caisse-badge><?= session()->get('caisse_is_active')  ? session()->get('caisse_nom') : 'Aucune caisse' ?></span>
        </div>

        <nav class="sidebar-nav nav flex-column">
          <a href="#" class="nav-link active"><i class="bi bi-house-door-fill"></i> Accueil</a>
          <a href="<?= site_url('achat/saisie') ?>" class="nav-link"><i class="bi bi-cart-plus-fill"></i> Saisie des achats</a>
        </nav>

        <div class="sidebar-footer">
          <a href="<?= site_url('auth/disconnect') ?>" class="logout-link"><i class="bi bi-box-arrow-right"></i> Déconnexion</a>
        </div>

      </div>
    </div>
    <!-- ===================== /SIDEBAR ===================== -->

    <main class="app-main d-flex align-items-center justify-content-center">
      <div class="card select-caisse-card w-100">
        <div class="card-body p-4 p-md-5 text-center">

          <div class="select-caisse-icon mx-auto mb-3">
            <i class="bi bi-shop"></i>
          </div>

          <h1 class="h4 mb-1">Sélection de la caisse</h1>
          <p class="text-muted-ink mb-4">Choisissez votre poste pour commencer à enregistrer des achats.</p>

          <form id="accueilForm" class="needs-validation text-start" action="/caisse/choix" method="post">
            <div class="mb-4">
              <label for="caisseSelect" class="form-label">Caisse</label>
              <select class="form-select" id="caisseSelect" name="nomCaisse" required>
                <option value="" selected disabled>Choisir une caisse…</option>
                <?php foreach($caisses as $caisse): ?>
                  <option value="<?= esc($caisse['nom']) ?>"><?= esc($caisse['nom']) ?></option>
                <?php endforeach; ?>
              </select>
              <div class="invalid-feedback">Merci de sélectionner une caisse.</div>
            </div>

            <button type="submit" class="btn btn-primary w-100 py-2">
              <i class="bi bi-check-circle me-1"></i> Valider
            </button>
          </form>

        </div>
      </div>
    </main>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/app.js"></script>
</body>
</html>
